﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    internal static class Configuration
    {
        internal static string ConnectionString = @"Server=DESKTOP-2DFP0EC\SQLEXPRESS;Database=StudentSystemDb;Integrated Security=true;";
    }
}
