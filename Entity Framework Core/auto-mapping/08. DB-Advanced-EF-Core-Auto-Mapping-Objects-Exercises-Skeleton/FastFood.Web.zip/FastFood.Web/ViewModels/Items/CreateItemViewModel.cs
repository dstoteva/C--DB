﻿namespace FastFood.Web.ViewModels.Items
{
    public class CreateItemViewModel
    {
        public int CategoryId { get; set; }
    }
}
